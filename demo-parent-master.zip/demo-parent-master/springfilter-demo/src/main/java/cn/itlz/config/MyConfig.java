package cn.itlz.config;

/**
 * @author Liuzd
 * @since 2018/11/19 0019
 */
public class MyConfig {
}
