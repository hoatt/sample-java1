package cn.itlz;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

/**
 * @author Liuzd
 * Desc:
 * Date: 2018/11/9 0009
 */
@SpringBootApplication
public class SpringFilterDemoApplication {
    public static void main(String[] args) {
        SpringApplication.run(SpringFilterDemoApplication.class,args);
    }
}
