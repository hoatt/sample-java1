package cn.itlz.demo.neo4j.domain;

import lombok.Data;

/**
 * @author Liuzd QQ: 77822013 2019/5/30 0030
 */
@Data
public class Person {

    private Long id;
    private String name;
    private Integer age;
}
