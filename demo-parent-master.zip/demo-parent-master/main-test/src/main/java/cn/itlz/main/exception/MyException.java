package cn.itlz.main.exception;

/**
 * @author Liuzd QQ：77822013  2019/3/8 0008
 */
public class MyException extends RuntimeException {
}
