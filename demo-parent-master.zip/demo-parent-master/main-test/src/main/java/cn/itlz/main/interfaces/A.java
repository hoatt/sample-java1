package cn.itlz.main.interfaces;

/**
 * @author Liuzd
 * Desc:
 * Date: 2018/11/11 0011
 */
public interface A {
    void test();
}
