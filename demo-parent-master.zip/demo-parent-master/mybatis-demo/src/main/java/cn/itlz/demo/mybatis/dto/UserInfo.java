package cn.itlz.demo.mybatis.dto;

import lombok.Data;

/**
 * @author Liuzd QQ：77822013  2019/3/5 0005
 */
@Data
public class UserInfo {

    private String name;

    private Integer score;
}
