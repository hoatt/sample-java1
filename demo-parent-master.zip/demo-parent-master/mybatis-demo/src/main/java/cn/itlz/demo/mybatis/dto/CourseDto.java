package cn.itlz.demo.mybatis.dto;

import lombok.Data;

/**
 * @author Liuzd QQ: 77822013 2019/5/13 0013
 */
@Data
public class CourseDto {

    private String name;
    private String userName;
}
