package cn.itlz.demo.oauth2login.qq;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

/**
 * Desc:
 *
 * @author Liuzd
 * @since 2018/11/18 0018
 */
@SpringBootApplication
public class QQLoginApplication {
    public static void main(String[] args) {
        SpringApplication.run(QQLoginApplication.class,args);
    }
}
