package cn.itlz.demo.auth.dto;

/**
 * @author Liuzd QQ: 77822013
 * @since 2018/12/4 0004
 */
public class SimpleResponse {
    private Object contect;

    public Object getContect() {
        return contect;
    }

    public void setContect(Object contect) {
        this.contect = contect;
    }
}
