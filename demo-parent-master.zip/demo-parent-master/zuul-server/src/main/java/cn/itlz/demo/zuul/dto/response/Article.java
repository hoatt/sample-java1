package cn.itlz.demo.zuul.dto.response;

import lombok.Data;

/**
 * @author Liuzd QQ: 77822013
 * @since 2018/12/20 0020
 */
@Data
public class Article {

    private String title;
    private String desc;
    private String content;

}
