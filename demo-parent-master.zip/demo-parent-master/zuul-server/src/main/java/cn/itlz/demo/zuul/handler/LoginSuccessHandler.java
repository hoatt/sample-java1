package cn.itlz.demo.zuul.handler;

/**
 * @author Liuzd QQ: 77822013
 * @since 2018/12/12 0012
 */
/*
public class LoginSuccessHandler extends SimpleUrlAuthenticationSuccessHandler {

    @Override
    public void onAuthenticationSuccess(HttpServletRequest request, HttpServletResponse response, Authentication authentication) throws IOException, ServletException {
        getRedirectStrategy().sendRedirect(request, response, "http://localhost:3000");
    }
}
*/
