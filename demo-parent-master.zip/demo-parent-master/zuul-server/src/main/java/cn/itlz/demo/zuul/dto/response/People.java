package cn.itlz.demo.zuul.dto.response;

import lombok.Data;

/**
 * @author Liuzd QQ: 77822013
 * @since 2019/1/16 0016
 */
@Data
public class People {
    private String name ;
    private int age;
    private String height;
}
