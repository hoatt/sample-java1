package cn.itlz.java;

/**
 * @author liuzd <QQ: 77822013> 2019/9/28 0028
 */
public class CompletableFutureDemo {

    public static void main(String[] args) {

    }

}
