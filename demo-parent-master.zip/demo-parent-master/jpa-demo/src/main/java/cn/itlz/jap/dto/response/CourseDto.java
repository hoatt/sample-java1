package cn.itlz.jap.dto.response;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * @author Liuzd QQ: 77822013 2019/4/28 0028
 */
@Data
@AllArgsConstructor
@NoArgsConstructor
public class CourseDto {

    private String name;
    private String userName;
}
