package cn.itlz.jap;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

/**
 * @author Liuzd QQ: 77822013 2019/4/4 0004
 */
@SpringBootApplication
public class JpaApplication {
    
    public static void main(String[] args) {
        SpringApplication.run(JpaApplication.class, args);
    }
}
