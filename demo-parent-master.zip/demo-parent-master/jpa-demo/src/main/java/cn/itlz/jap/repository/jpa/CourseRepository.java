package cn.itlz.jap.repository.jpa;

import cn.itlz.jap.entity.Course;
import org.springframework.data.jpa.repository.JpaRepository;

/**
 * @author Liuzd QQ: 77822013 2019/4/17 0017
 */
public interface CourseRepository extends JpaRepository<Course,Long> {


}
