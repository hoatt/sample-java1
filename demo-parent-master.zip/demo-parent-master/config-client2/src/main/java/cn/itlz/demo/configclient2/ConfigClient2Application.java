package cn.itlz.demo.configclient2;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

/**
 * @author Liuzd QQ: 77822013
 * @since 2019/1/3 0003
 */
@SpringBootApplication
public class ConfigClient2Application {
    public static void main(String[] args) {
        SpringApplication.run(ConfigClient2Application.class, args);
    }
}
