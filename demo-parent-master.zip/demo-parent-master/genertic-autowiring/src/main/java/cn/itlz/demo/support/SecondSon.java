package cn.itlz.demo.support;

/**
 * @author Liuzd
 * Desc:
 * Date: 2018/11/13 0013
 */
public class SecondSon implements Parent {
    @Override
    public void say() {
        System.out.println("I'm SecondSon");
    }
}
