package cn.itlz.demo.support;

/**
 * @author Liuzd
 * Desc:
 * Date: 2018/11/13 0013
 */
public interface Parent {
    void say();
}
