package cn.itlz.demo.zuul.config;
import org.springframework.context.annotation.Configuration;

@Configuration
public class ZuulSecurityConfiguration {


}