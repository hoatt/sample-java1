package cn.itlz.demo.container.config;

import org.springframework.context.annotation.Configuration;

/**
 * @author Liuzd
 * Desc:
 * Date: 2018/11/18 0018
 */
@Configuration
public class Config {

}
