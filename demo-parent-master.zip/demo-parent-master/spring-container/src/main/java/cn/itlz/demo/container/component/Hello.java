package cn.itlz.demo.container.component;

/**
 * @author Liuzd
 * Desc:
 * Date: 2018/11/18 0018
 */
public class Hello {

    public Hello() {
        System.out.println("Hello实例化");
    }

    public void say() {
        System.out.println("hello");
    }
}
