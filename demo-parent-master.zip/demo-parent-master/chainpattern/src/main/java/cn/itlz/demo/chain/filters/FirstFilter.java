package cn.itlz.demo.chain.filters;

/**
 * @author Liuzd QQ: 77822013
 * @since 2018/12/8 0008
 */
public class FirstFilter {
}
