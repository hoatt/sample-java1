package cn.itlz.demo.chain;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

/**
 * @author Liuzd
 * Desc:
 * Date: 2018/11/17 0017
 */
@SpringBootApplication
public class ChianApplication {
    public static void main(String[] args) {
        SpringApplication.run(ChianApplication.class, args);
    }
}
