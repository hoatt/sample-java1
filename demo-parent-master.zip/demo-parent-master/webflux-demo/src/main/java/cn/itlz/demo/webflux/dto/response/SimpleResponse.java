package cn.itlz.demo.webflux.dto.response;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * @author Liuzd QQ: 77822013 2019/4/20 0020
 */
@Data
@AllArgsConstructor
@NoArgsConstructor
public class SimpleResponse {
    private String name;
}
