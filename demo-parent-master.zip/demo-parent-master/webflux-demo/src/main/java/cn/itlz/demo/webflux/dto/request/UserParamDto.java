package cn.itlz.demo.webflux.dto.request;

import lombok.Data;

/**
 * @author Liuzd QQ: 77822013 2019/4/20 0020
 */
@Data
public class UserParamDto {

    private String userName;
    private Integer age;
    private String email;
}
