package cn.itlz.rbac;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

/**
 * @author Liuzd QQ: 77822013 2019/3/23 0023
 */
@SpringBootApplication
public class RbacApplicationn {
    public static void main(String[] args) {
        SpringApplication.run(RbacApplicationn.class, args);
    }
}
